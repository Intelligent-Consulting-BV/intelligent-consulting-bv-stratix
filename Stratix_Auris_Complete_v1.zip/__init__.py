"""
STRATIX SDK
===========
Security Telemetry, Risk Attribution & Threat Intelligence eXchange

© 2026 Intelligent Consulting BV. All rights reserved.
Author: Suzanne Natalie Button, Director, Intelligent Consulting BV
Licence: Apache 2.0 (implementation use only)
First published: 26 February 2026

The STRATIX name, framework specification, schema design, governance model,
and certification programme are the exclusive intellectual property of
Intelligent Consulting BV, Brussels, Belgium.
Protected under EU Directive 2019/790/EU and the Berne Convention.
"""

__version__      = "1.0.0"
__author__       = "Suzanne Natalie Button"
__organisation__ = "Intelligent Consulting BV"
__copyright__    = "© 2026 Intelligent Consulting BV. All rights reserved."
__licence__      = "Apache-2.0"

from stratix.validator import (
    StratixValidator,
    StratixPipeline,
    AccessLogEntry,
    ValidationResult,
    IntentCategory,
    KillChainPhase,
    DataClassification,
    NIS2Category,
    EUCSAssuranceLevel,
    AIActClassification,
    GDPRLawfulBasis,
)

from stratix.mappers import (
    ECSToStratix,
    CIMToStratix,
    ASIMToStratix,
    ModbusToStratix,
    DNP3ToStratix,
    OPCUAToStratix,
    get_mapper,
)

from stratix.registry import (
    StratixRegistry,
    RegistryEntry,
)

__all__ = [
    # Validator
    "StratixValidator",
    "StratixPipeline",
    "AccessLogEntry",
    "ValidationResult",
    # Enumerations
    "IntentCategory",
    "KillChainPhase",
    "DataClassification",
    "NIS2Category",
    "EUCSAssuranceLevel",
    "AIActClassification",
    "GDPRLawfulBasis",
    # Mappers
    "ECSToStratix",
    "CIMToStratix",
    "ASIMToStratix",
    "ModbusToStratix",
    "DNP3ToStratix",
    "OPCUAToStratix",
    "get_mapper",
    # Registry
    "StratixRegistry",
    "RegistryEntry",
]
