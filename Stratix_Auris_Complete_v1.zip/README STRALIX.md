# STRATIX SDK

**Security Telemetry, Risk Attribution & Threat Intelligence eXchange**

> © 2026 Intelligent Consulting BV. All rights reserved.  
> Author: Suzanne Natalie Button, Director, Intelligent Consulting BV, Brussels, Belgium  
> First published: 26 February 2026  
> Licence: Apache 2.0 (implementation use); the STRATIX name, specification, and certification  
> standard remain the exclusive intellectual property of Intelligent Consulting BV.

---

## What is STRATIX?

STRATIX is a companion schema specification that sits above the Open Cybersecurity Schema  
Framework (OCSF), extending it across four critical layers without breaking OCSF compatibility:

| Layer | Name | Purpose |
|---|---|---|
| **1** | Behavioural Intent Attribution | ATT&CK mapping, confidence scoring, kill chain phase, blast radius |
| **2** | OT/ICS Event Classes | 8 native OT event classes aligned to IEC 62443 and the Purdue Model |
| **3** | EU Sovereignty Metadata | GDPR, NIS2, DORA, EUCS, and EU AI Act compliance fields |
| **4** | AI Telemetry Classes | 8 AI agent event classes for agentic SOC observability |

STRATIX is the schema foundation of **AURIS** (Autonomous Unified Response & Intelligence  
System) — the Intelligent Security Operations Platform architecture developed by  
Intelligent Consulting BV.

---

## Installation

```bash
# Core (validator + mappers + registry — no extra dependencies)
pip install stratix-sdk

# With REST API server
pip install stratix-sdk[api]

# With HTTP registry client
pip install stratix-sdk[http]

# Full install
pip install stratix-sdk[all]
```

---

## Quick Start

### Validate a STRATIX event

```python
from stratix import StratixValidator

validator = StratixValidator(strict=True)

event = {
    "class_uid": 4001,
    "category_uid": 4,
    "time": "2026-02-26T14:00:00+00:00",
    "metadata": {"version": "1.3.0"},
    "intent": {
        "category": "lateral_movement",
        "technique_id": "T1021.001",
        "confidence_score": 87,
        "kill_chain_phase": "actions_on_objectives",
    },
    "sovereignty": {
        "data_residency": "BE",
        "classification": "restricted",
        "nis2_category": "essential_entity",
        "eucs_assurance_level": "high",
    },
}

result = validator.validate(event)
print(result.valid)          # True
print(result.layer_results)  # {"ocsf_base": True, "intent": True, ...}
```

### Pipeline ingestion with quarantine

```python
from stratix import StratixPipeline

pipeline = StratixPipeline(strict=True, on_invalid="quarantine")

for raw_event in incoming_stream:
    clean_event = pipeline.process(raw_event)
    if clean_event:
        send_to_data_lake(clean_event)

print(pipeline.stats)
# {"valid": 9842, "invalid": 17, "quarantined": 17}
```

### Map Elastic ECS events to STRATIX

```python
from stratix.mappers import ECSToStratix

mapper = ECSToStratix()
stratix_event = mapper.map(ecs_raw_event)
```

### Map OT / Modbus frames to STRATIX

```python
from stratix.mappers import ModbusToStratix

mapper = ModbusToStratix()
stratix_event = mapper.map(
    frame,
    asset_id="PLC-REACTOR-01",
    purdue_level=1,
    data_residency="BE",
)
```

### Use the mapper factory

```python
from stratix.mappers import get_mapper

mapper = get_mapper("ecs")      # ECSToStratix
mapper = get_mapper("cim")      # CIMToStratix
mapper = get_mapper("asim")     # ASIMToStratix
mapper = get_mapper("modbus")   # ModbusToStratix
mapper = get_mapper("dnp3")     # DNP3ToStratix
mapper = get_mapper("opc-ua")   # OPCUAToStratix
```

### Publish an extension to the STRATIX Registry

```python
from stratix.registry import StratixRegistry, RegistryEntry

registry = StratixRegistry()

entry = RegistryEntry(
    name="energy-grid-events",
    display_name="Energy Grid OT Event Extension",
    version="0.1.0",
    domain="energy",
    sector="electricity",
    author="Your Name",
    organisation="Your Organisation",
    description="STRATIX extension for electricity grid OT events",
    schema_json={
        "grid_event": {
            "substation_id": "string",
            "voltage_level_kv": "number",
        }
    },
    tags=["energy", "NIS2", "grid"],
    nis2_aligned=True,
)

registry.publish(entry)
results = registry.search(domain="energy", nis2_aligned=True)
```

### CLI usage

```bash
# Validate a STRATIX event file
stratix-validate event.json

# Map an ECS event file to STRATIX
stratix-map --schema ecs --input event.json --output stratix_event.json

# Query the hosted STRATIX Registry
stratix-registry search --domain energy --nis2-aligned
```

---

## Supported Mappers

| Source Schema | Class | Description |
|---|---|---|
| Elastic ECS | `ECSToStratix` | Elastic Common Schema → STRATIX |
| Splunk CIM | `CIMToStratix` | Splunk Common Information Model → STRATIX |
| Microsoft ASIM | `ASIMToStratix` | Sentinel Advanced SIEM Info Model → STRATIX |
| Modbus | `ModbusToStratix` | Modbus TCP/RTU frames → STRATIX OT Layer |
| DNP3 | `DNP3ToStratix` | DNP3 frames → STRATIX OT Layer |
| OPC-UA | `OPCUAToStratix` | OPC Unified Architecture events → STRATIX OT Layer |

---

## STRATIX Registry

The STRATIX Registry is a versioned catalogue of domain-specific schema extensions built  
on the STRATIX core. Extensions are published by sector, domain, and regulatory alignment.

Public hosted registry: `https://registry.stratix.io`

To host your own registry instance:

```bash
pip install stratix-sdk[api]
uvicorn stratix.registry_api:app --host 0.0.0.0 --port 8000 --reload
```

---

## Regulatory Alignment

STRATIX Layer 3 (EU Sovereignty Metadata) provides native schema support for:

- **GDPR** (EU) 2016/679 — `gdpr_lawful_basis`, `access_log`, `data_residency`
- **NIS2** (EU) 2022/2555 — `nis2_category`, automatic 24h/72h notification triggers
- **DORA** (EU) 2022/2554 — `dora_ict_asset`, ICT incident classification
- **EUCS** — `eucs_assurance_level` (Basic / Substantial / High)
- **EU AI Act** — `ai_act_classification`, `ai.governance_audit_record`

---

## Intellectual Property

STRATIX is an original framework authored by **Suzanne Natalie Button**,  
Director, **Intelligent Consulting BV**, Brussels, Belgium.

This package is published under the **Apache 2.0 licence** for implementation use.  
The STRATIX name, framework specification, schema design, governance model, and  
certification programme are the exclusive intellectual property of Intelligent Consulting BV.

Protected under EU Directive 2019/790/EU and the Berne Convention.  
First published: 26 February 2026.

For licensing, certification, or advisory enquiries:  
**Intelligent Consulting BV | Brussels, Belgium**

---

## Contributing

Contributions to the STRATIX ecosystem — new vendor mappers, sector-specific registry  
extensions, tooling integrations — are welcome under the Apache 2.0 terms. The STRATIX  
core schema specification is governed exclusively by Intelligent Consulting BV.

See `CONTRIBUTING.md` for guidelines.
