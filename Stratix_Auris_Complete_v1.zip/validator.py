"""
stratix.validator
=================
STRATIX schema conformance validation library.

© 2026 Intelligent Consulting BV. All rights reserved.
Author: Suzanne Natalie Button, Director, Intelligent Consulting BV
Licence: Apache 2.0 (implementation use only)
First published: 26 February 2026
"""

from __future__ import annotations
import hashlib, json, re, uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional


class IntentCategory(str, Enum):
    INITIAL_ACCESS        = "initial_access"
    EXECUTION             = "execution"
    PERSISTENCE           = "persistence"
    PRIVILEGE_ESCALATION  = "privilege_escalation"
    DEFENCE_EVASION       = "defence_evasion"
    CREDENTIAL_ACCESS     = "credential_access"
    DISCOVERY             = "discovery"
    LATERAL_MOVEMENT      = "lateral_movement"
    COLLECTION            = "collection"
    COMMAND_AND_CONTROL   = "command_and_control"
    EXFILTRATION          = "exfiltration"
    IMPACT                = "impact"


class KillChainPhase(str, Enum):
    RECONNAISSANCE        = "reconnaissance"
    RESOURCE_DEVELOPMENT  = "resource_development"
    WEAPONISATION         = "weaponisation"
    DELIVERY              = "delivery"
    EXPLOITATION          = "exploitation"
    INSTALLATION          = "installation"
    COMMAND_AND_CONTROL   = "command_and_control"
    ACTIONS_ON_OBJECTIVES = "actions_on_objectives"


class DataClassification(str, Enum):
    PUBLIC       = "public"
    INTERNAL     = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED   = "restricted"
    SOVEREIGN    = "sovereign"


class NIS2Category(str, Enum):
    ESSENTIAL    = "essential_entity"
    IMPORTANT    = "important_entity"
    OUT_OF_SCOPE = "out_of_scope"


class EUCSAssuranceLevel(str, Enum):
    BASIC        = "basic"
    SUBSTANTIAL  = "substantial"
    HIGH         = "high"


class AIActClassification(str, Enum):
    UNACCEPTABLE = "unacceptable"
    HIGH_RISK    = "high_risk"
    LIMITED_RISK = "limited_risk"
    MINIMAL_RISK = "minimal_risk"


class GDPRLawfulBasis(str, Enum):
    CONSENT              = "consent"
    CONTRACT             = "contract"
    LEGAL_OBLIGATION     = "legal_obligation"
    VITAL_INTERESTS      = "vital_interests"
    PUBLIC_TASK          = "public_task"
    LEGITIMATE_INTERESTS = "legitimate_interests"


class ValidationResult:
    def __init__(self):
        self.valid: bool = True
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.layer_results: dict[str, bool] = {}

    def add_error(self, msg: str):
        self.errors.append(msg)
        self.valid = False

    def add_warning(self, msg: str):
        self.warnings.append(msg)

    def to_dict(self) -> dict:
        return {"valid": self.valid, "errors": self.errors,
                "warnings": self.warnings, "layer_results": self.layer_results}

    def __repr__(self):
        return json.dumps(self.to_dict(), indent=2)


class StratixValidator:
    TECHNIQUE_ID_PATTERN = re.compile(r"^T\d{4}(\.\d{3})?$")
    ISO3166_PATTERN       = re.compile(r"^[A-Z]{2}$")

    def __init__(self, strict: bool = True):
        self.strict = strict

    def validate(self, event: dict[str, Any]) -> ValidationResult:
        result = ValidationResult()
        self._validate_ocsf_base(event, result)
        self._validate_intent_layer(event.get("intent"), result)
        self._validate_sovereignty_layer(event.get("sovereignty"), result)
        self._validate_ot_layer(event.get("ot"), result)
        self._validate_ai_layer(event.get("ai"), result)
        return result

    def validate_batch(self, events: list[dict]) -> list[ValidationResult]:
        return [self.validate(e) for e in events]

    def _validate_ocsf_base(self, event, result):
        for field in ["class_uid", "category_uid", "time", "metadata"]:
            if field not in event:
                result.add_error(f"OCSF base: missing required field '{field}'")
        if "time" in event:
            try:
                datetime.fromisoformat(str(event["time"]).replace("Z", "+00:00"))
            except ValueError:
                result.add_error("OCSF base: 'time' must be ISO 8601 format")
        if "metadata" in event and "version" not in event["metadata"]:
            result.add_error("OCSF base: metadata.version is required")
        result.layer_results["ocsf_base"] = len(result.errors) == 0

    def _validate_intent_layer(self, intent, result):
        if intent is None:
            if self.strict:
                result.add_warning("STRATIX Layer 1: 'intent' block absent")
            result.layer_results["intent"] = False
            return
        eb = len(result.errors)
        if "category" not in intent:
            result.add_error("intent.category is required")
        else:
            try:
                IntentCategory(intent["category"])
            except ValueError:
                result.add_error(f"intent.category '{intent['category']}' invalid. "
                                  f"Must be one of: {[e.value for e in IntentCategory]}")
        if "technique_id" in intent and not self.TECHNIQUE_ID_PATTERN.match(intent["technique_id"]):
            result.add_error("intent.technique_id must match ATT&CK pattern e.g. T1078 or T1078.003")
        if "confidence_score" in intent:
            s = intent["confidence_score"]
            if not isinstance(s, (int, float)) or not (0 <= s <= 100):
                result.add_error("intent.confidence_score must be 0–100")
        if "kill_chain_phase" in intent:
            try:
                KillChainPhase(intent["kill_chain_phase"])
            except ValueError:
                result.add_error(f"intent.kill_chain_phase '{intent['kill_chain_phase']}' invalid. "
                                  f"Must be one of: {[e.value for e in KillChainPhase]}")
        result.layer_results["intent"] = len(result.errors) == eb

    def _validate_sovereignty_layer(self, sov, result):
        if sov is None:
            if self.strict:
                result.add_warning("STRATIX Layer 3: 'sovereignty' block absent")
            result.layer_results["sovereignty"] = False
            return
        eb = len(result.errors)
        if "data_residency" in sov and not self.ISO3166_PATTERN.match(str(sov["data_residency"])):
            result.add_error("sovereignty.data_residency must be ISO 3166-1 alpha-2 e.g. 'BE'")
        for field_name, enum_cls in [
            ("classification",       DataClassification),
            ("gdpr_lawful_basis",    GDPRLawfulBasis),
            ("nis2_category",        NIS2Category),
            ("eucs_assurance_level", EUCSAssuranceLevel),
            ("ai_act_classification",AIActClassification),
        ]:
            if field_name in sov:
                try:
                    enum_cls(sov[field_name])
                except ValueError:
                    result.add_error(f"sovereignty.{field_name} '{sov[field_name]}' invalid. "
                                      f"Must be one of: {[e.value for e in enum_cls]}")
        if "dora_ict_asset" in sov and not isinstance(sov["dora_ict_asset"], bool):
            result.add_error("sovereignty.dora_ict_asset must be a boolean")
        if "access_log" in sov:
            if not isinstance(sov["access_log"], list):
                result.add_error("sovereignty.access_log must be a list")
            else:
                for i, entry in enumerate(sov["access_log"]):
                    for req in ["accessor_id", "accessed_at", "signature"]:
                        if req not in entry:
                            result.add_error(f"sovereignty.access_log[{i}] missing '{req}'")
        result.layer_results["sovereignty"] = len(result.errors) == eb

    def _validate_ot_layer(self, ot, result):
        if ot is None:
            result.layer_results["ot"] = True
            return
        eb = len(result.errors)
        valid = ["plc_state_change","scada_alarm","process_deviation",
                 "industrial_protocol_event","zone_crossing",
                 "engineering_workstation_action","safety_system_event",
                 "asset_inventory_change"]
        if "event_class" not in ot:
            result.add_error("ot.event_class is required when 'ot' block is present")
        elif ot["event_class"] not in valid:
            result.add_error(f"ot.event_class '{ot['event_class']}' invalid. Must be one of: {valid}")
        if "purdue_level" in ot and ot["purdue_level"] not in [0,1,2,3,4,5]:
            result.add_error("ot.purdue_level must be an integer 0–5")
        result.layer_results["ot"] = len(result.errors) == eb

    def _validate_ai_layer(self, ai, result):
        if ai is None:
            result.layer_results["ai"] = True
            return
        eb = len(result.errors)
        valid = ["model_invocation","prompt_injection_attempt","tool_use",
                 "decision_trace","autonomous_action","human_escalation",
                 "model_drift_signal","governance_audit_record"]
        if "event_class" not in ai:
            result.add_error("ai.event_class is required when 'ai' block is present")
        elif ai["event_class"] not in valid:
            result.add_error(f"ai.event_class '{ai['event_class']}' invalid. Must be one of: {valid}")
        if "inference_location" in ai and not self.ISO3166_PATTERN.match(str(ai["inference_location"])):
            result.add_error("ai.inference_location must be ISO 3166-1 alpha-2")
        if ai.get("event_class") == "autonomous_action":
            if "authorisation_boundary" not in ai:
                result.add_error("ai.authorisation_boundary required for autonomous_action")
            if "action_type" not in ai:
                result.add_error("ai.action_type required for autonomous_action")
        result.layer_results["ai"] = len(result.errors) == eb


class AccessLogEntry:
    @staticmethod
    def create(accessor_id: str, event_id: str, purpose: str) -> dict:
        entry = {
            "accessor_id": accessor_id,
            "event_id":    event_id,
            "purpose":     purpose,
            "accessed_at": datetime.now(timezone.utc).isoformat(),
            "entry_id":    str(uuid.uuid4()),
        }
        payload = json.dumps(entry, sort_keys=True)
        entry["signature"] = hashlib.sha256(payload.encode()).hexdigest()
        return entry


class StratixPipeline:
    def __init__(self, strict: bool = True, on_invalid: str = "quarantine"):
        self.validator       = StratixValidator(strict=strict)
        self.on_invalid      = on_invalid
        self._valid_count    = 0
        self._invalid_count  = 0
        self._quarantine: list[dict] = []

    def process(self, event: dict) -> Optional[dict]:
        result = self.validator.validate(event)
        if result.valid:
            self._valid_count += 1
            return event
        self._invalid_count += 1
        if self.on_invalid == "quarantine":
            self._quarantine.append({"event": event, "errors": result.errors})
            return None
        if self.on_invalid == "drop":
            return None
        return event

    @property
    def stats(self) -> dict:
        return {"valid": self._valid_count, "invalid": self._invalid_count,
                "quarantined": len(self._quarantine)}

    @property
    def quarantine(self) -> list[dict]:
        return self._quarantine
